
import React from 'react';
import { Question } from '../types';

interface QuizCardProps {
  question: Question;
  selectedOption: string | null;
  onSelect: (option: string) => void;
  showFeedback: boolean;
}

const QuizCard: React.FC<QuizCardProps> = ({ 
  question, 
  selectedOption, 
  onSelect,
  showFeedback 
}) => {
  return (
    <div className="w-full max-w-2xl bg-white rounded-2xl shadow-xl overflow-hidden transition-all duration-300">
      <div className="p-8">
        <div className="flex items-center justify-between mb-6">
          <span className="px-3 py-1 text-xs font-semibold tracking-wider text-blue-600 uppercase bg-blue-100 rounded-full">
            Question {question.id}
          </span>
        </div>
        
        <h2 className="text-2xl font-bold text-gray-800 mb-8 leading-tight">
          {question.text}
        </h2>

        <div className="space-y-4">
          {question.options.map((option, index) => {
            const isSelected = selectedOption === option;
            const isCorrect = option === question.correctAnswer;
            
            let buttonClass = "w-full text-left p-4 rounded-xl border-2 transition-all duration-200 group relative flex items-center";
            
            if (showFeedback) {
              if (isCorrect) {
                buttonClass += " border-green-500 bg-green-50 text-green-700";
              } else if (isSelected && !isCorrect) {
                buttonClass += " border-red-500 bg-red-50 text-red-700";
              } else {
                buttonClass += " border-gray-100 opacity-50 grayscale cursor-not-allowed";
              }
            } else {
              buttonClass += isSelected 
                ? " border-blue-500 bg-blue-50 text-blue-700 shadow-md" 
                : " border-gray-100 hover:border-blue-200 hover:bg-gray-50 text-gray-700";
            }

            return (
              <button
                key={index}
                onClick={() => !showFeedback && onSelect(option)}
                disabled={showFeedback}
                className={buttonClass}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-4 flex-shrink-0 transition-colors ${
                  showFeedback && isCorrect 
                    ? 'bg-green-500 text-white' 
                    : showFeedback && isSelected && !isCorrect
                    ? 'bg-red-500 text-white'
                    : isSelected 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-gray-100 text-gray-500 group-hover:bg-blue-100 group-hover:text-blue-600'
                }`}>
                  {String.fromCharCode(65 + index)}
                </div>
                <span className="font-medium text-lg">{option}</span>
                
                {showFeedback && isCorrect && (
                  <svg className="w-6 h-6 ml-auto text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M5 13l4 4L19 7" />
                  </svg>
                )}
                {showFeedback && isSelected && !isCorrect && (
                  <svg className="w-6 h-6 ml-auto text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                )}
              </button>
            );
          })}
        </div>

        {showFeedback && (
          <div className={`mt-8 p-4 rounded-lg flex items-start space-x-3 transition-opacity duration-500 ${
            selectedOption === question.correctAnswer ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
          }`}>
            <span className="text-2xl">
              {selectedOption === question.correctAnswer ? '✨' : '📝'}
            </span>
            <div>
              <p className="font-bold">
                {selectedOption === question.correctAnswer ? 'Excellent! Correct Answer.' : 'Not quite. Review the correct answer above.'}
              </p>
              {selectedOption !== question.correctAnswer && (
                <p className="mt-1 text-sm opacity-90">The correct answer is: <strong>{question.correctAnswer}</strong></p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuizCard;
