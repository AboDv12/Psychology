
import React from 'react';

interface NavigationProps {
  onNext: () => void;
  onPrev: () => void;
  currentIndex: number;
  totalQuestions: number;
  isAnswered: boolean;
}

const Navigation: React.FC<NavigationProps> = ({
  onNext,
  onPrev,
  currentIndex,
  totalQuestions,
  isAnswered
}) => {
  return (
    <div className="flex items-center justify-between w-full max-w-2xl mt-8">
      <button
        onClick={onPrev}
        disabled={currentIndex === 0}
        className="flex items-center px-6 py-3 text-sm font-semibold text-gray-700 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-sm"
      >
        <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
        </svg>
        Back
      </button>

      <button
        onClick={onNext}
        disabled={!isAnswered && currentIndex < totalQuestions - 1}
        className={`flex items-center px-8 py-3 text-sm font-semibold text-white rounded-xl shadow-lg transition-all transform active:scale-95 ${
          currentIndex === totalQuestions - 1
            ? 'bg-indigo-600 hover:bg-indigo-700'
            : isAnswered
            ? 'bg-blue-600 hover:bg-blue-700'
            : 'bg-gray-300 cursor-not-allowed'
        }`}
      >
        {currentIndex === totalQuestions - 1 ? 'Finish Quiz' : 'Next Question'}
        <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
        </svg>
      </button>
    </div>
  );
};

export default Navigation;
