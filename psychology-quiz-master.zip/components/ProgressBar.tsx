
import React from 'react';

interface ProgressBarProps {
  current: number;
  total: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ current, total }) => {
  const percentage = Math.round(((current + 1) / total) * 100);
  
  return (
    <div className="w-full max-w-2xl mb-8">
      <div className="flex justify-between items-end mb-2">
        <span className="text-sm font-bold text-blue-600">Question Progress</span>
        <span className="text-xs font-medium text-gray-500">{current + 1} of {total} ({percentage}%)</span>
      </div>
      <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
        <div 
          className="h-full bg-blue-500 transition-all duration-500 ease-out rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)]" 
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
};

export default ProgressBar;
