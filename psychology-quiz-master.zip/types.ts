
export interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: string;
}

export interface QuizState {
  currentQuestionIndex: number;
  userAnswers: Record<number, string>;
  isFinished: boolean;
}
