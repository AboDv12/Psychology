
import { Question } from './types';

export const psychologyQuestions: Question[] = [
  {
    id: 1,
    text: "Is a familiar mass communication medium for most urban women.",
    options: ["News paper", "TV", "BOTH A and B", "None of the above"],
    correctAnswer: "BOTH A and B"
  },
  {
    id: 2,
    text: "The most common channel of communication is:",
    options: ["Mass communication", "Interpersonal communication (IPC)", "Both", "None of the above"],
    correctAnswer: "Interpersonal communication (IPC)"
  },
  {
    id: 3,
    text: "Modern Media used for instant message dissemination:",
    options: ["News bulletins in TV/Radio", "Face book", "Internet", "All of the above"],
    correctAnswer: "All of the above"
  },
  {
    id: 4,
    text: "We can communicate with a large number of people through:",
    options: ["Mass media", "All of the above", "Print media", "TV"],
    correctAnswer: "All of the above"
  },
  {
    id: 5,
    text: "Which of the following is a counseling skill?",
    options: ["Socialism", "Criticism", "Empathy", "Sympathy"],
    correctAnswer: "Empathy"
  },
  {
    id: 6,
    text: "Which of the following is direct communication?",
    options: ["Radio", "News paper", "Face to face communication", "None of the above"],
    correctAnswer: "Face to face communication"
  },
  {
    id: 7,
    text: "When breaking the bad news, the patients emotional reactions (crying and weeping) should be addressed with:",
    options: ["Patient's perception", "Attention", "Empathy", "Availability"],
    correctAnswer: "Empathy"
  },
  {
    id: 8,
    text: "Empathy is defined as:",
    options: ["Denying emotions", "Exploratory response", "Contradicting", "One needs to listen and identify the emotion that patient is experiencing and offer an acknowledgment"],
    correctAnswer: "One needs to listen and identify the emotion that patient is experiencing and offer an acknowledgment"
  },
  {
    id: 9,
    text: "It is an essential therapeutic strategy of a practicing doctor to:",
    options: ["to have frequent follow up visits", "checking adherence to medicines on daily basis", "To give patient money to buy medicines", "activate social support around a patient"],
    correctAnswer: "checking adherence to medicines on daily basis"
  },
  {
    id: 10,
    text: "What is health Communication?",
    options: ["Utterance of words", "Speaking to people", "Conveying the message", "Exchange of thoughts, messages, or information, as by speech, signal, or writing"],
    correctAnswer: "Exchange of thoughts, messages, or information, as by speech, signal, or writing"
  },
  {
    id: 11,
    text: "The three components of a campaign setting include:",
    options: ["Time, Day, Location", "Time, Location, and Situation", "Look, Feel, Surroundings", "Time, Look, Feel"],
    correctAnswer: "Time, Location, and Situation"
  },
  {
    id: 12,
    text: "Risk communicators, in crafting risk messages, must ensure that their messages:",
    options: ["Reach the audience", "Capture the attention of the audience", "Convince the audience", "All of the above"],
    correctAnswer: "All of the above"
  },
  {
    id: 13,
    text: "“Highlighting Facts” in message creation is a form of which of the following?",
    options: ["Influence", "Information", "Pressure", "None of the above"],
    correctAnswer: "Influence"
  },
  {
    id: 14,
    text: "In order for a health communication program to have an impact, the source of the content is:",
    options: ["Kept up to date", "Incredible", "Old", "Limited"],
    correctAnswer: "Kept up to date"
  },
  {
    id: 15,
    text: "Effective health communication strategy must take:",
    options: ["Multi-pronged approach", "Policy changes", "Evidence-based", "All of the above"],
    correctAnswer: "All of the above"
  },
  {
    id: 16,
    text: "Barriers to Effective Health Communication include:",
    options: ["Language barriers", "Illiterate", "Socio-cultural differences", "All of the above"],
    correctAnswer: "All of the above"
  },
  {
    id: 17,
    text: "Features of Effective Interpersonal Communication include:",
    options: ["Patient not understands his or her medical condition", "Full disclosure of information by the patient", "Partial disclosure of information by the patient", "Patients not understand the nature of their illness"],
    correctAnswer: "Full disclosure of information by the patient"
  },
  {
    id: 18,
    text: "Most important things to do if a medical error is committed:",
    options: ["proceed without attention", "ignore an error", "cover up an error", "Admit the mistake and apologize for it"],
    correctAnswer: "Admit the mistake and apologize for it"
  },
  {
    id: 19,
    text: "Encoding that occurs with no effort or a minimal level of conscious attention is known as:",
    options: ["Implicit memory", "Long term potentiation", "State dependent memory", "Chunking", "Automatic processing"],
    correctAnswer: "Automatic processing"
  },
  {
    id: 20,
    text: "The cerebellum plays a critical role in ______ memory:",
    options: ["Implicit", "Echoic", "Iconic", "Explicit"],
    correctAnswer: "Implicit"
  },
  {
    id: 21,
    text: "The fact that given a list or series of words/numbers we can recall the first and last numbers better is:",
    options: ["Serial Position Effect", "Sensory Memory", "Spacing Effect", "Short-term Memory"],
    correctAnswer: "Serial Position Effect"
  },
  {
    id: 22,
    text: "Multiple choice questions test our:",
    options: ["Relearning", "Recognition", "Recall"],
    correctAnswer: "Recognition"
  },
  {
    id: 23,
    text: "The process by which we process an external event into memory is as follows:",
    options: [
      "Sensory Memory, Long-term Memory, Short-term Memory.",
      "Short-term Memory, Long-term Memory, Sensory Memory.",
      "Sensory Memory, Short-term Memory, Long-term Memory."
    ],
    correctAnswer: "Sensory Memory, Short-term Memory, Long-term Memory."
  },
  {
    id: 24,
    text: "Functions such as Skills and motor Cognition are found to be this type of long-term memory:",
    options: ["Explicit", "Implicit"],
    correctAnswer: "Implicit"
  },
  {
    id: 25,
    text: "Fill in the (space) questions test our:",
    options: ["Relearning", "Recognition", "Recall"],
    correctAnswer: "Recall"
  },
  {
    id: 26,
    text: "Which of the following is an open-ended question?",
    options: [
      "Could you tell me the name of the prime minister?",
      "Do you have trouble falling asleep?",
      "Tell me about yourself?",
      "It seems as if you feel people are against you?",
      "What do you find stressful in your job?"
    ],
    correctAnswer: "Tell me about yourself?"
  },
  {
    id: 27,
    text: "Statement: 'So you have been anxious since that incident occurred at your work place.' Which technique is this?",
    options: ["Reflecting", "Facilitation", "Open-ended question", "Interpretation", "Closed-ended question"],
    correctAnswer: "Reflecting"
  },
  {
    id: 28,
    text: "Typically, bullying from boys is to _____ as bullying from girls is to _____:",
    options: [
      "psychological harm; physical harm",
      "verbal taunting; psychological harm",
      "physical harm; emotional harm",
      "social exclusion; verbal taunting",
      "emotional harm; physical harm"
    ],
    correctAnswer: "physical harm; emotional harm"
  },
  {
    id: 29,
    text: "Which of the following adolescents is least likely to be targeted for bullying?",
    options: [
      "a child with a physical disability",
      "a transgender adolescent",
      "an emotionally sensitive boy",
      "the captain of the football team",
      "none of the above"
    ],
    correctAnswer: "the captain of the football team"
  },
  {
    id: 30,
    text: "Transference feelings are based on:",
    options: [
      "doctors projecting their feelings to the patient",
      "is a main reason for lawsuits filed by mistreated patients",
      "Don't occur with a highly experienced physician",
      "a patient projecting feelings from past relationships to the doctor",
      "none of the above"
    ],
    correctAnswer: "a patient projecting feelings from past relationships to the doctor"
  },
  {
    id: 31,
    text: "In which instance is an active-passive patient-doctor relationship most appropriate?",
    options: [
      "A young woman confides about wanting an abortion.",
      "A carrier of the cystic fibrosis gene consulting a doctor.",
      "A woman wishes to monitor her own blood pressure at home.",
      "A patient with chronic illness choosing treatment options.",
      "A 22-year-old man brought into the ER with a gunshot wound to the chest."
    ],
    correctAnswer: "A 22-year-old man brought into the ER with a gunshot wound to the chest."
  },
  {
    id: 32,
    text: "A 4 year-old child is unable to consider another child's ideas about playing house. This illustrates:",
    options: ["Reversibility and spatiality", "Object permanence", "Formal operations", "Egocentrism"],
    correctAnswer: "Egocentrism"
  },
  {
    id: 33,
    text: "The statement 'Growth involves resolution of critical tasks through the eight stages of the life cycle' belongs to:",
    options: ["Cognitive-behavioral", "Psychoanalytic", "Interpersonal", "Intrapersonal (Erikson's developmental theory)"],
    correctAnswer: "Intrapersonal (Erikson's developmental theory)"
  },
  {
    id: 34,
    text: "Which scenario describes an individual in Erikson's stage of 'old age' exhibiting despair?",
    options: [
      "A 65 year-old man discussing life's accomplishments",
      "A 70 year-old woman angry about where her life has ended up",
      "A 50 year-old man reviewing his life",
      "A 60 year-old woman taking care of her mother"
    ],
    correctAnswer: "A 70 year-old woman angry about where her life has ended up"
  },
  {
    id: 35,
    text: "Which is an example of an individual successfully completing Erikson's 'school age' stage?",
    options: [
      "A 5 year-old boy asking others to play hide-and-seek",
      "An 11 year-old girl is trying out for cheerleading",
      "A 14 year-old girl resisting peer pressure",
      "A 3 year-old boy playing by himself"
    ],
    correctAnswer: "An 11 year-old girl is trying out for cheerleading"
  },
  {
    id: 36,
    text: "Which initial information is most important when assessing Erikson's stages?",
    options: [
      "The chronological age of the individual",
      "The developmental age through behaviors",
      "The time frame needed to complete a previous stage",
      "The implementation of interventions"
    ],
    correctAnswer: "The chronological age of the individual"
  },
  {
    id: 37,
    text: "According to Maslow, which action corresponds to seeking safety and security?",
    options: [
      "Practicing assertiveness skills",
      "Seeking shelter at a center for battered women",
      "Discussing the need for order",
      "Seeking to share life experiences",
      "Realizing full potential"
    ],
    correctAnswer: "Seeking shelter at a center for battered women"
  },
  {
    id: 38,
    text: "According to Maslow, which action is an example of a high-level need (self-fulfillment)?",
    options: [
      "Achieving success and recognition",
      "Giving and receiving support",
      "Avoiding harm and maintaining comfort",
      "Beginning to discuss feelings of self-fulfillment"
    ],
    correctAnswer: "Beginning to discuss feelings of self-fulfillment"
  },
  {
    id: 39,
    text: "Which situation on a psychiatric unit violates Safety and Security needs?",
    options: [
      "Exhibiting hostile behaviors toward another client",
      "Stating 'I have never met my career goals'",
      "Disturbed that family visits are limited",
      "Stating 'I have no one who cares about me'"
    ],
    correctAnswer: "Exhibiting hostile behaviors toward another client"
  },
  {
    id: 40,
    text: "Which person statement is correctly matched with the personality structure (Id/Ego/Superego)?",
    options: [
      "'I'll return the purse. It's never right to steal.' : Superego",
      "'I need that car. No one will miss it.' : Id",
      "'Cheating could get me expelled, so I won't.' : Ego",
      "All of the above"
    ],
    correctAnswer: "All of the above"
  },
  {
    id: 41,
    text: "According to Maslow, which situation demonstrates the lowest level of attainment?",
    options: [
      "Avoiding harm while maintaining physical safety",
      "Discussing all points of view objectively",
      "Desiring prestige from personal accomplishments",
      "Establishing meaningful interpersonal relationships"
    ],
    correctAnswer: "Avoiding harm while maintaining physical safety"
  },
  {
    id: 42,
    text: "An individual fired from work states: 'Imagine what I can do with this extra time.' This defense mechanism is:",
    options: ["Intellectualization", "Suppression", "Denial", "Rationalization"],
    correctAnswer: "Rationalization"
  },
  {
    id: 43,
    text: "Which exemplifies the defense mechanism of reaction formation?",
    options: [
      "Attending AA while still drinking",
      "Calling the nurse when not angry",
      "Joining a crisis center after a traumatic event",
      "Being unhappy about being a father but appearing overly attentive to others"
    ],
    correctAnswer: "Being unhappy about being a father but appearing overly attentive to others"
  },
  {
    id: 44,
    text: "Which exemplifies the defense mechanism of compensation?",
    options: [
      "Using alcohol to overcome shyness",
      "Curling into fetal position after injury",
      "Yelling at an assistant for minimal mistakes",
      "A woman feels unattractive but decides to pursue fashion design as a career"
    ],
    correctAnswer: "A woman feels unattractive but decides to pursue fashion design as a career"
  },
  {
    id: 45,
    text: "Which exemplifies the defense mechanism of sublimation?",
    options: [
      "Becoming a therapist to help others with anger",
      "Reminding a friend not to steal",
      "Admiring nurses and wanting a nursing career",
      "A man who loves sports but is unable to play becomes an athletic trainer"
    ],
    correctAnswer: "A man who loves sports but is unable to play becomes an athletic trainer"
  },
  {
    id: 46,
    text: "When are defense mechanisms typically used adaptive according to Freud?",
    options: [
      "At times of mild to moderate anxiety",
      "Only by mentally ill individuals",
      "When anxiety decreases",
      "When the superego is tested"
    ],
    correctAnswer: "At times of mild to moderate anxiety"
  },
  {
    id: 47,
    text: "Not remembering a car accident is unconsciously using which defense mechanism?",
    options: ["Rationalization", "Suppression", "Undoing", "Repression"],
    correctAnswer: "Repression"
  },
  {
    id: 48,
    text: "Showing no emotion when discussing a violent attack is exhibiting:",
    options: ["Compensation", "Regression", "Isolation", "Displacement"],
    correctAnswer: "Isolation"
  },
  {
    id: 49,
    text: "Dressing like Sigmund Freud after failing an exam is which defense mechanism?",
    options: ["Reaction formation", "Repression", "Identification", "Regression"],
    correctAnswer: "Identification"
  },
  {
    id: 50,
    text: "Which situation reflects the defense mechanism of projection?",
    options: [
      "A promiscuous wife accuses her husband of having an affair",
      "A wife failing to conceive becomes teacher of the year",
      "A man remembering nothing of a childhood assault",
      "A husband buys a diamond bracelet after having an affair"
    ],
    correctAnswer: "A promiscuous wife accuses her husband of having an affair"
  },
  {
    id: 51,
    text: "Which situation reflects the defense mechanism of denial?",
    options: [
      "Taking golf lessons when a brother excels",
      "Thinking 50% survive a diagnosis",
      "Pulling a cat's tail after being spanked",
      "After years of excessive drinking, failing to acknowledge a problem"
    ],
    correctAnswer: "After years of excessive drinking, failing to acknowledge a problem"
  },
  {
    id: 52,
    text: "Expressing anger at a sister-in-law instead of an ex-husband is:",
    options: ["Displacement", "Projection", "Rationalization", "Denial"],
    correctAnswer: "Displacement"
  },
  {
    id: 53,
    text: "Which personality disorder cluster is correctly matched?",
    options: [
      "Cluster A: avoidant/dependent; odd character",
      "Cluster B: antisocial/borderline; Dramatic character",
      "Cluster C: avoidant/dependent; Anxious or fearful",
      "Cluster C: antisocial; dramatic character"
    ],
    correctAnswer: "Cluster C: avoidant/dependent; Anxious or fearful"
  },
  {
    id: 54,
    text: "Behavior expected in paranoid personality disorder:",
    options: [
      "Sitting alone and stating, 'Everyone wants to hurt me.'",
      "Allows others to make decisions",
      "Refuses to talk due to low self-esteem",
      "Exploits peers for cigarettes"
    ],
    correctAnswer: "Sitting alone and stating, 'Everyone wants to hurt me.'"
  },
  {
    id: 55,
    text: "Diagnostic criterion for schizotypal personality disorder:",
    options: [
      "Considers relationships more intimate than they are",
      "Neither desires nor enjoys close relationships",
      "Unjustified doubts about loyalty",
      "Exhibits behavior or appearance that is odd, eccentric, or peculiar"
    ],
    correctAnswer: "Exhibits behavior or appearance that is odd, eccentric, or peculiar"
  },
  {
    id: 56,
    text: "Characteristic of borderline personality disorder:",
    options: [
      "Recurrent suicidal and self-mutilating behaviors",
      "Frantic efforts to avoid abandonment",
      "Chronic feelings of emptiness",
      "All of the above"
    ],
    correctAnswer: "All of the above"
  },
  {
    id: 57,
    text: "Characteristic of avoidant personality disorder:",
    options: [
      "Does not form intimate relationships due to fear of shame",
      "Difficulty making decisions without reassurance",
      "Views self as socially inept and inferior",
      "Both A and C"
    ],
    correctAnswer: "Both A and C"
  },
  {
    id: 58,
    text: "Assessing histrionic personality disorder identifying characteristic:",
    options: [
      "Orderliness and perfection",
      "Odd beliefs and magical thinking",
      "Attention-seeking flamboyance",
      "Grandiose sense of self-importance"
    ],
    correctAnswer: "Attention-seeking flamboyance"
  },
  {
    id: 59,
    text: "Characteristic of passive-aggressive traits:",
    options: [
      "Reckless disregard for safety",
      "Unjustified doubts about trustworthiness",
      "Seeks subtle retribution when feeling wronged",
      "Attempts to 'split' the staff"
    ],
    correctAnswer: "Seeks subtle retribution when feeling wronged"
  },
  {
    id: 60,
    text: "Common traits among all personality disorder clusters include:",
    options: ["Lack of insight", "Failure to accept consequences", "Cope by altering environment", "All of the above"],
    correctAnswer: "All of the above"
  },
  {
    id: 61,
    text: "Which is an example of an artificial concept?",
    options: ["Teachers", "Gemstones", "Mammals", "A triangles area"],
    correctAnswer: "A triangles area"
  },
  {
    id: 62,
    text: "An event schema is also known as cognitive:",
    options: ["Script", "Stereotype", "Concept", "Prototype"],
    correctAnswer: "Script"
  },
  {
    id: 63,
    text: "What provides principles for organizing words into sentences?",
    options: ["Lexicon", "Syntax", "Semantics", "Linguistic determinism"],
    correctAnswer: "Syntax"
  },
  {
    id: 64,
    text: "Smallest unit of language that carries meaning:",
    options: ["Phonemes", "Lexicon", "Syntax", "Morphemes"],
    correctAnswer: "Morphemes"
  },
  {
    id: 65,
    text: "Meaning of words is determined by applying rules of:",
    options: ["Overgeneralization", "Lexicon", "Phonemes", "Semantics"],
    correctAnswer: "Semantics"
  },
  {
    id: 66,
    text: "Basic sound units of a spoken language:",
    options: ["Morphemes", "Syntax", "Grammar", "Phonemes"],
    correctAnswer: "Phonemes"
  },
  {
    id: 67,
    text: "A specific formula for solving a problem is called:",
    options: ["Trial and error", "A mental set", "A heuristic", "An algorithm"],
    correctAnswer: "An algorithm"
  },
  {
    id: 68,
    text: "A mental shortcut problem-solving framework is:",
    options: ["Trial and error", "A mental set", "A heuristic", "An algorithm"],
    correctAnswer: "A heuristic"
  },
  {
    id: 69,
    text: "Which of the following is not one of Gardner's Multiple Intelligences?",
    options: ["Spatial", "Musical", "Linguistic", "Creative"],
    correctAnswer: "Creative"
  },
  {
    id: 70,
    text: "Which theorist put forth the triarchic theory of intelligence?",
    options: ["Goleman", "Sternberg", "Steitz", "Gardner"],
    correctAnswer: "Sternberg"
  },
  {
    id: 71,
    text: "Looking for trends in data uses which intelligence most?",
    options: ["Practical", "Analytical", "Emotional", "Creative"],
    correctAnswer: "Analytical"
  },
  {
    id: 72,
    text: "The mean score for a person with an average IQ is:",
    options: ["130", "100", "70", "85"],
    correctAnswer: "100"
  },
  {
    id: 73,
    text: "Who developed the IQ test most widely used today?",
    options: ["David Wechsler", "Sir Francis Galton", "Alfred Binet", "Louis Terman"],
    correctAnswer: "David Wechsler"
  },
  {
    id: 74,
    text: "Current (APA 2013) diagnostic label for mental retardation:",
    options: ["Lowered intelligence", "Cognitive disruption", "Autism", "Intellectual disability"],
    correctAnswer: "Intellectual disability"
  },
  {
    id: 75,
    text: "External stressors include the following except:",
    options: ["Loss of money", "Loss of a friend", "Thoughts", "Change in work place"],
    correctAnswer: "Thoughts"
  },
  {
    id: 76,
    text: "Internal stressors include the following except:",
    options: ["Environmental changes", "Attitudes", "Thoughts", "Believes"],
    correctAnswer: "Environmental changes"
  },
  {
    id: 77,
    text: "Distress includes the following except:",
    options: ["Death of friend", "marriage", "Car troubles", "work demands"],
    correctAnswer: "marriage"
  },
  {
    id: 78,
    text: "Factors that influence response to stress include:",
    options: ["Past experiences", "Development stage", "Intensity of stressor", "All of the above"],
    correctAnswer: "All of the above"
  },
  {
    id: 79,
    text: "Infant greets returning mother with pleasure. According to Bowlby:",
    options: ["Insecure attachment", "Infantile neurosis", "Easy temperament", "Secure attachment"],
    correctAnswer: "Secure attachment"
  },
  {
    id: 80,
    text: "10 year old interested in school/athletics. Stage in Freud's theory:",
    options: ["Separation-individualization", "Object constancy", "Concrete operational", "Latency", "Industry versus inferiority"],
    correctAnswer: "Latency"
  },
  {
    id: 81,
    text: "Theorist focused on early interpersonal experience and sense of self:",
    options: ["Klein", "Piaget", "Erikson", "Kohut", "Freud"],
    correctAnswer: "Kohut"
  },
  {
    id: 82,
    text: "70 year old lying about age. Stage in Erikson's theory failing mastery:",
    options: ["Pragmatic stage", "Egocentric stage", "Narcissistic stage", "Integrity versus despair stage"],
    correctAnswer: "Integrity versus despair stage"
  },
  {
    id: 83,
    text: "In psychoanalytic theory, the superego:",
    options: ["Reduces guilt", "Is totally unconscious", "Is a defense mechanism", "Contains the ego ideal"],
    correctAnswer: "Contains the ego ideal"
  },
  {
    id: 84,
    text: "Boy crawling under couch for ball. Characteristic thinking in Piaget's theory:",
    options: ["Sensory-motor stage", "Object permanence", "Object constancy", "Initiative versus guilt"],
    correctAnswer: "Object permanence"
  },
  {
    id: 85,
    text: "9 month old girl bursts into tears with unfamiliar adult:",
    options: ["Stranger anxiety", "Insecure attachment", "Separation anxiety", "Simple phobia"],
    correctAnswer: "Stranger anxiety"
  },
  {
    id: 86,
    text: "9 month old stranger anxiety is:",
    options: ["Symptom of insecure attachment", "Likely to persist", "Anxiety disorder indicator", "Common in normal infants"],
    correctAnswer: "Common in normal infants"
  },
  {
    id: 87,
    text: "Erikson's theories differ from Freud's by placing emphasis on:",
    options: ["Psychosexual development", "Object relations", "Cultural factors in development", "Instinctual drives"],
    correctAnswer: "Cultural factors in development"
  },
  {
    id: 88,
    text: "Child hit by father later slaps sister for dropping toy. Mechanism:",
    options: ["Rationalization", "Reaction formation", "Displacement", "Sublimation"],
    correctAnswer: "Displacement"
  },
  {
    id: 89,
    text: "Girl loves father's attention and says she will marry him. Freud stage:",
    options: ["Oral", "Anal", "Phallic", "Latency"],
    correctAnswer: "Phallic"
  },
  {
    id: 90,
    text: "Which theory was NOT proposed by Sigmund Freud?",
    options: ["structural model", "topographical model", "individual psychology theory", "affect trauma theory"],
    correctAnswer: "individual psychology theory"
  },
  {
    id: 91,
    text: "All are functions of the ego EXCEPT:",
    options: ["control of drives", "rational judgment", "mediation of reality", "accommodating the ego ideal"],
    correctAnswer: "accommodating the ego ideal"
  },
  {
    id: 92,
    text: "Which is not a mature defense mechanism?",
    options: ["humour", "anticipation", "sublimation", "isolation", "altruism"],
    correctAnswer: "isolation"
  },
  {
    id: 93,
    text: "Which is NOT a projective test?",
    options: ["Draw a person", "Thematic apperception", "MMPI", "Rorschach"],
    correctAnswer: "MMPI"
  },
  {
    id: 94,
    text: "Boy recognizes water amount remains same in different glasses. Piaget stage:",
    options: ["Sensorymotor", "Concrete operational", "Preoperational", "Formal operational"],
    correctAnswer: "Concrete operational"
  },
  {
    id: 95,
    text: "Near objects seem to move past faster than distant objects:",
    options: ["linear perspective", "aerial perspective", "relative size", "relative motion"],
    correctAnswer: "relative motion"
  },
  {
    id: 96,
    text: "Objects near each other tend to be grouped together:",
    options: ["nearness", "similarity", "closure", "continuation"],
    correctAnswer: "nearness"
  },
  {
    id: 97,
    text: "Tendency to group same size, shape, or color objects together:",
    options: ["closure", "continuation", "similarity", "nearness"],
    correctAnswer: "similarity"
  },
  {
    id: 98,
    text: "Perceiving an opening door as rectangular despite trapezoidal retinal image:",
    options: ["shape constancy", "perceptual closure", "ambiguous stimuli", "retinal disparity"],
    correctAnswer: "shape constancy"
  },
  {
    id: 99,
    text: "Tendency to fill in gaps in the perception of a figure:",
    options: ["sensory completion", "closure", "continuation", "figure-ground"],
    correctAnswer: "closure"
  },
  {
    id: 100,
    text: "Observing two identical cars and perceiving them as identical despite image size changes:",
    options: ["shape constancy", "size constancy", "concept constancy", "form constancy"],
    correctAnswer: "size constancy"
  },
  {
    id: 101,
    text: "Decreased perceptual response to a repeated stimulus is called:",
    options: ["divided attention", "habituation", "selective attention", "hallucination"],
    correctAnswer: "habituation"
  },
  {
    id: 102,
    text: "White shirt reflects more light outdoors but seen as equally bright indoors. Role of:",
    options: ["brightness parallax", "brightness constancy", "lightness constancy", "visual limitations"],
    correctAnswer: "lightness constancy"
  },
  {
    id: 103,
    text: "An ability to 'read' another person's mind is termed:",
    options: ["precognition", "telepathy", "clairvoyance", "psychokinesis"],
    correctAnswer: "telepathy"
  },
  {
    id: 104,
    text: "Sensations are organized into meaningful perceptions by:",
    options: ["sensory adaptation", "perceptual constancies", "localization of meaning", "perceptual grouping (Gestalt) principles"],
    correctAnswer: "perceptual grouping (Gestalt) principles"
  },
  {
    id: 105,
    text: "Imaginary perception of something that does not exist:",
    options: ["illusion", "hallucination", "stroboscopic movement", "Muller-Lyer illusion"],
    correctAnswer: "hallucination"
  },
  {
    id: 106,
    text: "Internal standards used to judge stimuli are referred to as:",
    options: ["frames of reference", "context", "intuition", "adaptation level"],
    correctAnswer: "frames of reference"
  },
  {
    id: 107,
    text: "Illusions are:",
    options: ["not based on reality", "distortions of existing stimuli", "innate mechanisms", "same as hallucinations"],
    correctAnswer: "distortions of existing stimuli"
  },
  {
    id: 108,
    text: "Door opens toward you, perceived as rectangular despite trapezoid image shape:",
    options: ["retinal disparity", "ambiguous stimuli", "shape constancy", "perceptual closure"],
    correctAnswer: "shape constancy"
  },
  {
    id: 109,
    text: "The tendency to fill in gaps in figure perception:",
    options: ["closure", "continuation", "sensory completion", "figure-ground"],
    correctAnswer: "closure"
  },
  {
    id: 110,
    text: "Stimuli organized as three columns instead of six due to:",
    options: ["closure", "continuity", "nearness", "similarity"],
    correctAnswer: "nearness"
  },
  {
    id: 111,
    text: "Sensations organized into meaningful perceptions by grouping principles:",
    options: ["Gestalt principles", "localization of meaning", "perceptual constancies"],
    correctAnswer: "Gestalt principles"
  },
  {
    id: 112,
    text: "Television ads in black and white use which attention getter?",
    options: ["motion", "repetition", "contrast", "loudness"],
    correctAnswer: "contrast"
  },
  {
    id: 113,
    text: "Extrinsic motivation stems from:",
    options: ["primary drives", "obvious external factors", "Self-actualization", "intrinsic motivation"],
    correctAnswer: "obvious external factors"
  },
  {
    id: 114,
    text: "Which of the following is a primary motive?",
    options: ["physical contact", "desire for money", "Thirst", "Curiosity"],
    correctAnswer: "Thirst"
  },
  {
    id: 115,
    text: "Nervous system part preparing body for emergencies:",
    options: ["Adaptive", "Parasympathetic", "Somatic", "Sympathetic"],
    correctAnswer: "Sympathetic"
  },
  {
    id: 116,
    text: "Autonomic system part responsible for restoring/conserving energy:",
    options: ["somatic", "sympathetic", "parasympathetic", "limbic"],
    correctAnswer: "parasympathetic"
  },
  {
    id: 117,
    text: "Beating heart and dry mouth before diving are produced by:",
    options: ["endorphins", "cortisone", "adrenaline", "amines"],
    correctAnswer: "adrenaline"
  },
  {
    id: 118,
    text: "If the ventromedial hypothalamus is destroyed, a rat will:",
    options: ["refuse to eat", "eat until obese", "drink excessively", "refuse to drink"],
    correctAnswer: "eat until it becomes obese"
  },
  {
    id: 119,
    text: "Theory claiming emotions, feelings, and body react simultaneously:",
    options: ["common sense", "James-Lange", "attribution", "Cannon-Bard"],
    correctAnswer: "Cannon-Bard"
  },
  {
    id: 120,
    text: "Theory of emotion stating bodily changes PRECEDE emotion:",
    options: ["James-Lange", "Cannon-Bard", "attribution", "common sense"],
    correctAnswer: "James-Lange"
  },
  {
    id: 121,
    text: "Sensory distortions reported under sensory deprivation support:",
    options: ["opponent-process", "Arousal theory", "drive reduction", "Episodic theory"],
    correctAnswer: "Arousal theory"
  },
  {
    id: 122,
    text: "Declining work quality after rumor of factory closure is due to motivation for:",
    options: ["safety and security", "esteem", "intrinsic motivation", "meta-needs"],
    correctAnswer: "safety and security"
  },
  {
    id: 123,
    text: "Maslow's basic needs include:",
    options: ["safety, love", "security, esteem", "physiological, belonging", "physiological, safety, security"],
    correctAnswer: "physiological, safety, security"
  },
  {
    id: 124,
    text: "At the top of Maslow's hierarchy are:",
    options: ["self-actualization", "esteem", "love", "safety"],
    correctAnswer: "self-actualization"
  },
  {
    id: 125,
    text: "Mixture of physiological arousal, behavior, and thought:",
    options: ["Emotions", "Needs", "Beliefs", "All of these"],
    correctAnswer: "Emotions"
  },
  {
    id: 126,
    text: "Emotions differ from moods in that emotions:",
    options: ["multi-component", "clear cause", "longer lasting", "both A and B"],
    correctAnswer: "both A and B"
  },
  {
    id: 127,
    text: "Seeing a lion in living room vs zoo causes different arousal. Illustrates:",
    options: ["Cannon's theory", "cognitive appraisal role", "James-Lange", "facial feedback"],
    correctAnswer: "cognitive appraisal role"
  },
  {
    id: 128,
    text: "Cognitive appraisals are largely responsible for:",
    options: ["determining physiological response", "differentiating facial expressions", "differentiating emotions", "behavioral response"],
    correctAnswer: "differentiating emotions"
  },
  {
    id: 129,
    text: "James argues physiological patterns are ___ for emotions; Schachter argues they are ___:",
    options: ["same, different", "different, the same", "same, same", "different, different"],
    correctAnswer: "different, the same"
  },
  {
    id: 130,
    text: "William James theory differed from Schachter because James ignored:",
    options: ["Behavioral", "Cognitive", "Physiological", "Evolutionary"],
    correctAnswer: "Cognitive"
  },
  {
    id: 131,
    text: "Aggressive response after running up stairs supports:",
    options: ["James lange", "Schachter and Singers two factor", "Misattribution of arousal", "facial feedback"],
    correctAnswer: "Misattribution of arousal"
  },
  {
    id: 132,
    text: "Minimalist appraisal theories reduce emotional appraisals to:",
    options: ["core patterns", "small range of dimensions", "6 dimensions", "minimal sufficient dimensions"],
    correctAnswer: "core patterns"
  },
  {
    id: 133,
    text: "Cognitive appraisals of emotions result from:",
    options: ["conscious and unconscious processing", "None", "only conscious", "only unconscious"],
    correctAnswer: "conscious and unconscious processing"
  },
  {
    id: 134,
    text: "Sitting in waiting room and experiencing fear from past treatment is:",
    options: ["rational modulation", "non specific arousal", "emotion without cognition", "emotion without arousal"],
    correctAnswer: "emotion without cognition"
  },
  {
    id: 135,
    text: "Positive emotional appraisals lead to:",
    options: ["playfulness", "increased life span", "openness to experience", "all of the above"],
    correctAnswer: "all of the above"
  },
  {
    id: 136,
    text: "Skin temperature reduced during:",
    options: ["Grief, sadness", "Surprise, anger", "anger, happiness", "fear, disgust"],
    correctAnswer: "fear, disgust"
  },
  {
    id: 137,
    text: "Physiological responses to negative vs positive emotions differ because:",
    options: ["Heart rate decreased for positive", "Skin temp increased for positive", "Heart rate increased for positive", "None"],
    correctAnswer: "Heart rate decreased for positive"
  },
  {
    id: 138,
    text: "According to James-Lange, you know you are afraid of snakes because:",
    options: ["cognitive appraisal", "you run when you see one", "all choices", "learning about poison"],
    correctAnswer: "you run when you see one"
  },
  {
    id: 139,
    text: "'I'm afraid because my forehead muscles tense up.' Illustrates:",
    options: ["James-Lange", "Cannon", "psychodynamic", "humanistic"],
    correctAnswer: "James-Lange"
  },
  {
    id: 140,
    text: "Studies of identifying emotions in photos from other cultures show:",
    options: ["difficult to judge", "expression varies widely", "universal meaning for certain expressions", "wide variations"],
    correctAnswer: "universal meaning for certain expressions"
  },
  {
    id: 141,
    text: "Joining Peace Corps requires least training for understanding:",
    options: ["meal customs", "linguistics", "body posture", "facial expressions"],
    correctAnswer: "facial expressions"
  },
  {
    id: 142,
    text: "Learned aspects of emotional expression are called:",
    options: ["native expressions", "display rules", "experience rules", "cognitive appraisals"],
    correctAnswer: "display rules"
  },
  {
    id: 143,
    text: "Reason for different cultural recognition of emotional expressions:",
    options: ["genetic differences", "emotional display rule differences", "facial structure", "all expressions differ"],
    correctAnswer: "emotional display rule differences"
  },
  {
    id: 144,
    text: "Facial expression exerts influence on experience:",
    options: ["indirectly (arousal)", "indirectly (appraisal)", "only in suggestible people", "directly (feedback)"],
    correctAnswer: "directly (feedback)"
  },
  {
    id: 145,
    text: "Aspect of emotions less susceptible to gender and culture effects:",
    options: ["preceding appraisal", "linked to responses", "subjective experience", "all choices"],
    correctAnswer: "preceding appraisal"
  },
  {
    id: 146,
    text: "Aspect of emotions most susceptible to gender and culture effects:",
    options: ["bodily responses", "linked to responses to emotions", "subjective experience", "both B and D"],
    correctAnswer: "both B and D"
  },
  {
    id: 147,
    text: "Correct sequence for motivational process:",
    options: ["response-drive-need", "drive-response-need", "need-drive-response", "reinforcement-need-response"],
    correctAnswer: "need-drive-response"
  },
  {
    id: 148,
    text: "Workers quality down due to factory closure rumor motivated by:",
    options: ["intrinsic", "esteem", "safety and security", "meta-needs"],
    correctAnswer: "safety and security"
  },
  {
    id: 149,
    text: "Theory of emotion: bodily changes PRECEDE emotion:",
    options: ["attribution", "Cannon-Bard", "common sense", "James-Lange"],
    correctAnswer: "James-Lange"
  },
  {
    id: 150,
    text: "Motivation initiates, directs, and ____ activities of the organism:",
    options: ["sustaining", "suspending", "supplying", "surveying"],
    correctAnswer: "sustaining"
  },
  {
    id: 151,
    text: "Which statement about sex drive is TRUE in humans?",
    options: ["hormone influence decreases as we ascend scale", "greatly affected by hormones", "necessary for individual survival", "homeostatic"],
    correctAnswer: "hormone influence decreases as we ascend scale"
  },
  {
    id: 152,
    text: "Theory: emotions feelings and body react simultaneously:",
    options: ["attribution", "Cannon-Bard", "James-Lange", "common sense"],
    correctAnswer: "Cannon-Bard"
  },
  {
    id: 153,
    text: "Body is dehydrated but you are not thirsty:",
    options: ["both drive and need", "drive but not need", "neither", "need but not drive"],
    correctAnswer: "need but not drive"
  },
  {
    id: 154,
    text: "Secondary motives are:",
    options: ["needs that are learned (power/achievement)", "innate/survival", "innate/not survival", "learned/survival"],
    correctAnswer: "needs that are learned (power/achievement)"
  },
  {
    id: 155,
    text: "Emotion vs Motivation: emotion aroused by ___, motivation by ___:",
    options: ["instincts, drives", "drives, instincts", "internal, external", "external, internal"],
    correctAnswer: "external, internal"
  },
  {
    id: 156,
    text: "Infant greets returning mother with pleasure (outstretched arms). Theory type:",
    options: ["Oral phase", "Insecure attachment", "Secure attachment", "Infantile neurosis"],
    correctAnswer: "Secure attachment"
  },
  {
    id: 157,
    text: "10-year-old interested in school/athletics. Psychosexual development stage:",
    options: ["Separation-individualtion", "Industry versus inferiority", "Latency", "Concrete operational"],
    correctAnswer: "Latency"
  },
  {
    id: 158,
    text: "70-year-old woman lies about age, avoids 'grandmother' label. Erikson stage:",
    options: ["Pragmatic stage", "Integrity versus despair", "Generative vs stagnation", "Egocentric stage"],
    correctAnswer: "Integrity versus despair"
  },
  {
    id: 159,
    text: "In psychoanalytic theory, the superego contains:",
    options: ["ego ideal", "sexual drives", "reduced guilt function", "defense mechanism"],
    correctAnswer: "ego ideal"
  },
  {
    id: 160,
    text: "29-month-old crawls under couch for ball. Piaget's thinking concept:",
    options: ["Initiative vs guilt", "Basic trust", "Object constancy", "Sensory-motor stage", "Object permanence"],
    correctAnswer: "Object permanence"
  },
  {
    id: 161,
    text: "9-month-old bursts into tears when handed to adult. Behavior due to:",
    options: ["Insecure attachment", "Depressive position", "Separation anxiety", "Simple phobia", "Stranger anxiety"],
    correctAnswer: "Stranger anxiety"
  },
  {
    id: 162,
    text: "9-month-old stranger anxiety behavior is:",
    options: ["Common in normal infants", "Pervasive disorder symptom", "Likely to persist", "Always insecure attachment"],
    correctAnswer: "Common in normal infants"
  },
  {
    id: 163,
    text: "Erikson developmental theories emphasis vs Freud:",
    options: ["Object relations", "Instinctual drives", "Psychosexual development", "Cultural factors"],
    correctAnswer: "Cultural factors"
  },
  {
    id: 164,
    text: "Child hit by father for breaking vase later slaps sister for dropping toy train:",
    options: ["Rationalization", "Reaction formation", "Displacement", "Isolation", "Repression"],
    correctAnswer: "Displacement"
  },
  {
    id: 165,
    text: "6-month-old puts everything in mouth and sucks pacifier to sleep. Freud stage:",
    options: ["Oral", "Anal", "Phallic", "Latency"],
    correctAnswer: "Oral"
  },
  {
    id: 166,
    text: "Which theory was not proposed by Sigmund Freud?",
    options: ["psychosexual stages", "affect trauma theory", "topographical model", "individual psychology theory"],
    correctAnswer: "individual psychology theory"
  },
  {
    id: 167,
    text: "All are functions of the ego EXCEPT:",
    options: ["accommodating the ego ideal", "forming relationships", "mediation of reality", "control of instinctual drives"],
    correctAnswer: "accommodating the ego ideal"
  },
  {
    id: 168,
    text: "Which is not a mature defense mechanism?",
    options: ["altruism", "sublimation", "anticipation", "humour", "isolation"],
    correctAnswer: "isolation"
  },
  {
    id: 169,
    text: "Which of the following is NOT a projective test?",
    options: ["Thematic apperception", "MMPI", "Rorschach", "Draw a person"],
    correctAnswer: "MMPI"
  },
  {
    id: 170,
    text: "Boy recognizes water amount remains same in different glasses. Piaget stage attained:",
    options: ["Preoperational", "Formal operational", "Conventional", "Concrete operational"],
    correctAnswer: "Concrete operational"
  },
  {
    id: 171,
    text: "Theorist focused on early interpersonal experience and sense of self:",
    options: ["Kohut", "Klein", "Piaget", "Erikson", "Freud"],
    correctAnswer: "Kohut"
  }
];
