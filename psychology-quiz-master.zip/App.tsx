
import React, { useState, useCallback, useMemo } from 'react';
import { psychologyQuestions } from './data';
import QuizCard from './components/QuizCard';
import Navigation from './components/Navigation';
import ProgressBar from './components/ProgressBar';

const App: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [showResult, setShowResult] = useState(false);

  const currentQuestion = psychologyQuestions[currentIndex];
  const isAnswered = !!userAnswers[currentQuestion.id];

  const handleSelect = useCallback((option: string) => {
    setUserAnswers(prev => ({
      ...prev,
      [currentQuestion.id]: option
    }));
  }, [currentQuestion.id]);

  const handleNext = useCallback(() => {
    if (currentIndex < psychologyQuestions.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      setShowResult(true);
    }
  }, [currentIndex]);

  const handlePrev = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  }, [currentIndex]);

  const score = useMemo(() => {
    return psychologyQuestions.reduce((acc, q) => {
      return userAnswers[q.id] === q.correctAnswer ? acc + 1 : acc;
    }, 0);
  }, [userAnswers]);

  const resetQuiz = () => {
    setCurrentIndex(0);
    setUserAnswers({});
    setShowResult(false);
  };

  if (showResult) {
    const percentage = Math.round((score / psychologyQuestions.length) * 100);
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
        <div className="w-full max-w-xl bg-white rounded-3xl shadow-2xl p-10 text-center animate-in fade-in zoom-in duration-500">
          <div className="mb-6 inline-flex p-4 bg-blue-100 rounded-full text-blue-600">
            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h1 className="text-4xl font-black text-gray-900 mb-2">Quiz Complete!</h1>
          <p className="text-gray-500 mb-8 font-medium">Excellent work on completing the Psychology Assessment.</p>
          
          <div className="grid grid-cols-2 gap-4 mb-10">
            <div className="p-6 bg-blue-50 rounded-2xl border border-blue-100">
              <span className="block text-3xl font-bold text-blue-700">{score} / {psychologyQuestions.length}</span>
              <span className="text-xs font-bold text-blue-500 uppercase tracking-widest">Score</span>
            </div>
            <div className="p-6 bg-indigo-50 rounded-2xl border border-indigo-100">
              <span className="block text-3xl font-bold text-indigo-700">{percentage}%</span>
              <span className="text-xs font-bold text-indigo-500 uppercase tracking-widest">Accuracy</span>
            </div>
          </div>

          <div className="space-y-4">
            <button 
              onClick={resetQuiz}
              className="w-full py-4 px-6 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl shadow-lg transition-all transform hover:-translate-y-1"
            >
              Restart Quiz
            </button>
            <p className="text-sm text-gray-400">Review your answers above or retake the assessment.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto flex flex-col items-center">
        <header className="text-center mb-12">
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight mb-2">
            Psychology <span className="text-blue-600">Quizzss</span>
          </h1>
          <p className="text-slate-500 font-medium">Test your knowledge on key behavioral theories and communication skills</p>
        </header>

        <ProgressBar current={currentIndex} total={psychologyQuestions.length} />

        <QuizCard
          question={currentQuestion}
          selectedOption={userAnswers[currentQuestion.id] || null}
          onSelect={handleSelect}
          showFeedback={isAnswered}
        />

        <Navigation
          onNext={handleNext}
          onPrev={handlePrev}
          currentIndex={currentIndex}
          totalQuestions={psychologyQuestions.length}
          isAnswered={isAnswered}
        />

        <footer className="mt-16 text-center text-slate-400 text-sm">
          <p>&copy; 2025 Psychology Assessment Portal. Professional Study Resource.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
